<?php

namespace App\Http\Controllers;

use App\Models\Kunjungan;
use App\Models\Wbp;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class KunjunganController extends Controller
{
    public function index()
    {
        $kunjungan = Kunjungan::with('kunjungan','kunjunganWbp')->get();
        // dd($kunjungan);
        return view('admin.kunjungan.kunjungan', compact('kunjungan'));
    }

    public function create()
    {
        $wbp = Wbp::all();
        return view('admin.kunjungan.tambah-kunjungan',compact('wbp'));
    }

    public function store(Request $request)
    {

        $kunjungan = new kunjungan();
        $kunjungan->user_id = Auth()->user()->id;
        $kunjungan->wbp_nomor_identitas = $request->nomor_identitas;
        $kunjungan->tgl_kunjungan = $request->tanggal_kunjungan;
        $kunjungan->hubungan = $request->hubungan;
        $kunjungan->status = 'menunggu';
        // dd($kunjungan);
        $kunjungan->save();



        return redirect()->route('kunjungan.index');
    }

    public function edit($id)
    {
        $kunjungan = Kunjungan::findOrFail($id);
        return view('admin.kunjungan.edit-kunjungan', compact('kunjungan'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'nomor_identitas' => 'required',
            'jenis_kelamin' => 'required|string',
            'tanggal_lahir' => 'required|date',
            'alamat' => 'required|string',
            'status' => 'required|string',
            'kasus' => 'required|string',
            'tanggal_masuk' => 'required|date',
        ]);
        // dd($validated);

        $kunjungan = Kunjungan::findOrFail($id);
        $kunjungan->update($validated);

        return redirect()->route('kunjungan.index');
    }

    public function destroy($id)
    {
        $kunjungan = Kunjungan::findOrFail($id);
        $kunjungan->delete();

        return redirect()->route('kunjungan.index');
    }
}

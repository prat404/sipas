<?php

namespace App\Http\Controllers;

use App\Models\Wbp;
use Illuminate\Http\Request;

class WbpController extends Controller
{
    public function index()
    {
        $wbp = Wbp::all();
        return view('admin.wbp.wbp', compact('wbp'));
    }

    public function create()
    {
        return view('admin.wbp.tambah-wbp');
    }

    public function store(Request $request)
    {

        $wbp = new Wbp();
        $wbp->nama = $request->nama;
        $wbp->nomor_identitas = $request->nomor_identitas;
        $wbp->jenis_kelamin = $request->jenis_kelamin;
        $wbp->tanggal_lahir = $request->tanggal_lahir;
        $wbp->alamat = $request->alamat;
        $wbp->tanggal_masuk = $request->tanggal_masuk;
        $wbp->kasus = $request->kasus;
        $wbp->status = 'dibina';
        // dd($wbp);
        $wbp->save();



        return redirect()->route('wbp.index');
    }

    public function edit($id)
    {
        $wbp = Wbp::findOrFail($id);
        return view('admin.wbp.edit-wbp', compact('wbp'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'nomor_identitas' => 'required',
            'jenis_kelamin' => 'required|string',
            'tanggal_lahir' => 'required|date',
            'alamat' => 'required|string',
            'status' => 'required|string',
            'kasus' => 'required|string',
            'tanggal_masuk' => 'required|date',
        ]);
        // dd($validated);

        $wbp = Wbp::findOrFail($id);
        $wbp->update($validated);

        return redirect()->route('wbp.index');
    }

    public function destroy($id)
    {
        $wbp = Wbp::findOrFail($id);
        $wbp->delete();

        return redirect()->route('wbp.index');
    }
}

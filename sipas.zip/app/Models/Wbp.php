<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Wbp extends Model
{
    use HasFactory;
    protected $table = 'wbp';
    protected $fillable = [
        'nama', 
        'nomor_identitas', 
        'jenis_kelamin', 
        'tanggal_lahir', 
        'alamat', 
        'status', 
        'kasus', 
        'tanggal_masuk', 
        'tanggal_keluar'
    ];

    public function wbp(){
        return $this->hasMany(Kunjungan::class, 'wbp_nomor_identitas','nomor_identitas' );
    }
}

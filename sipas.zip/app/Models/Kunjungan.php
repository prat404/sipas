<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kunjungan extends Model
{
    use HasFactory;
    protected $table = 'kunjungans';
    protected $fillable = [
        'user_id', 
        'wbp_nomor_identitas', 
        'tanggal_kunjungan', 
        'hubungan', 
        'status', 
        'ket', 
    ];

    public function kunjungan(){
        return $this->hasOne(User::class,'id');
    }
    public function kunjunganWbp(){
        return $this->hasOne(Wbp::class, 'nomor_identitas', 'wbp_nomor_identitas');
    }
}
